package com.example.loginsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {
    Button btndevice;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btndevice = (Button) findViewById(R.id.btndevice);
        DB = new DBHelper(this);

        btndevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(HomeActivity.this, "", Toast.LENGTH_SHORT).show();
                Intent intent  = new Intent(getApplicationContext(), DevicesActivity.class);
                startActivity(intent);
            }
        });
    }
}